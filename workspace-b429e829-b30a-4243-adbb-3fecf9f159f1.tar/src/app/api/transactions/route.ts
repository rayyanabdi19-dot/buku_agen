import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const dailyStatusId = searchParams.get('dailyStatusId')

    if (!dailyStatusId) {
      return NextResponse.json(
        { success: false, message: 'Daily Status ID diperlukan!' },
        { status: 400 }
      )
    }

    const transactions = await db.transaction.findMany({
      where: { dailyStatusId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      transactions: transactions.map(tx => ({
        id: tx.id,
        type: tx.type,
        amount: tx.amount,
        fee: tx.fee,
        timestamp: tx.createdAt.toISOString(),
        customerName: tx.customerName,
        target: tx.target,
        status: tx.status
      }))
    })
  } catch (error) {
    console.error('Get transactions error:', error)
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat mengambil transaksi' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { userId, dailyStatusId, type, amount, fee, customerName, target } = await request.json()

    if (!userId || !dailyStatusId || !type || !amount) {
      return NextResponse.json(
        { success: false, message: 'Data tidak lengkap!' },
        { status: 400 }
      )
    }

    // Create transaction
    const transaction = await db.transaction.create({
      data: {
        userId,
        dailyStatusId,
        type: type.toUpperCase(),
        amount: parseFloat(amount),
        fee: parseFloat(fee || 0),
        customerName: customerName || 'Customer Umum',
        target: target || '-',
        status: 'SUCCESS'
      }
    })

    // Calculate new balances
    const allTransactions = await db.transaction.findMany({
      where: { dailyStatusId }
    })

    const dailyStatus = await db.dailyStatus.findUnique({
      where: { id: dailyStatusId }
    })

    if (!dailyStatus) {
      return NextResponse.json(
        { success: false, message: 'Status harian tidak ditemukan!' },
        { status: 404 }
      )
    }

    let cashBalance = dailyStatus.cashStart
    let bankBalance = dailyStatus.bankStart

    allTransactions.forEach(tx => {
      if (tx.type === 'TOPUP') {
        if (tx.customerName?.toUpperCase().includes('KAS LACI')) {
          cashBalance += tx.amount
        } else if (tx.customerName?.toUpperCase().includes('REKENING')) {
          bankBalance += tx.amount
        }
      } else if (tx.type === 'TARIK') {
        cashBalance -= tx.amount
        bankBalance += tx.amount + tx.fee
      } else {
        // SETOR or TRANSFER
        cashBalance += tx.amount + tx.fee
        bankBalance -= tx.amount
      }
    })

    return NextResponse.json({
      success: true,
      transaction: {
        id: transaction.id,
        type: transaction.type,
        amount: transaction.amount,
        fee: transaction.fee,
        timestamp: transaction.createdAt.toISOString(),
        customerName: transaction.customerName,
        target: transaction.target,
        status: transaction.status
      },
      cashBalance,
      bankBalance
    })
  } catch (error) {
    console.error('Create transaction error:', error)
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat membuat transaksi' },
      { status: 500 }
    )
  }
}
