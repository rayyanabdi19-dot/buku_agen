import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const userId = searchParams.get('userId')
    const date = searchParams.get('date')

    if (!userId || !date) {
      return NextResponse.json(
        { success: false, message: 'User ID dan tanggal diperlukan!' },
        { status: 400 }
      )
    }

    const dailyStatus = await db.dailyStatus.findFirst({
      where: {
        userId,
        date,
        status: 'OPEN'
      }
    })

    if (!dailyStatus) {
      return NextResponse.json({ success: false, dailyStatus: null })
    }

    // Calculate current balances
    const allTransactions = await db.transaction.findMany({
      where: { dailyStatusId: dailyStatus.id }
    })

    let cashBalance = dailyStatus.cashStart
    let bankBalance = dailyStatus.bankStart

    allTransactions.forEach(tx => {
      if (tx.type === 'TOPUP') {
        if (tx.customerName?.toUpperCase().includes('KAS LACI')) {
          cashBalance += tx.amount
        } else if (tx.customerName?.toUpperCase().includes('REKENING')) {
          bankBalance += tx.amount
        }
      } else if (tx.type === 'TARIK') {
        cashBalance -= tx.amount
        bankBalance += tx.amount + tx.fee
      } else {
        // SETOR or TRANSFER
        cashBalance += tx.amount + tx.fee
        bankBalance -= tx.amount
      }
    })

    return NextResponse.json({
      success: true,
      dailyStatus: {
        id: dailyStatus.id,
        userId: dailyStatus.userId,
        date: dailyStatus.date,
        cashStart: dailyStatus.cashStart,
        bankStart: dailyStatus.bankStart,
        timeOpen: dailyStatus.timeOpen.toISOString(),
        timeClose: dailyStatus.timeClose?.toISOString(),
        status: dailyStatus.status
      },
      cashBalance,
      bankBalance
    })
  } catch (error) {
    console.error('Get daily status error:', error)
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat mengambil status harian' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { userId, date, cashStart, bankStart } = await request.json()

    if (!userId || !date || cashStart === undefined || bankStart === undefined) {
      return NextResponse.json(
        { success: false, message: 'Data tidak lengkap!' },
        { status: 400 }
      )
    }

    // Check if there's already an open shift for this date
    const existingStatus = await db.dailyStatus.findFirst({
      where: {
        userId,
        date,
        status: 'OPEN'
      }
    })

    if (existingStatus) {
      return NextResponse.json(
        { success: false, message: 'Shift sudah dibuka untuk tanggal ini!' },
        { status: 400 }
      )
    }

    const dailyStatus = await db.dailyStatus.create({
      data: {
        userId,
        date,
        cashStart: parseFloat(cashStart),
        bankStart: parseFloat(bankStart),
        timeOpen: new Date(),
        status: 'OPEN'
      }
    })

    return NextResponse.json({
      success: true,
      dailyStatus: {
        id: dailyStatus.id,
        userId: dailyStatus.userId,
        date: dailyStatus.date,
        cashStart: dailyStatus.cashStart,
        bankStart: dailyStatus.bankStart,
        timeOpen: dailyStatus.timeOpen.toISOString(),
        timeClose: dailyStatus.timeClose?.toISOString(),
        status: dailyStatus.status
      }
    })
  } catch (error) {
    console.error('Create daily status error:', error)
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat membuat status harian' },
      { status: 500 }
    )
  }
}
