import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { name, phone, pin } = await request.json()

    if (!name || !phone || !pin) {
      return NextResponse.json(
        { success: false, message: 'Semua kolom harus diisi!' },
        { status: 400 }
      )
    }

    if (pin.length !== 6) {
      return NextResponse.json(
        { success: false, message: 'PIN harus 6 digit!' },
        { status: 400 }
      )
    }

    const existingUser = await db.user.findUnique({
      where: { phone }
    })

    if (existingUser) {
      return NextResponse.json(
        { success: false, message: 'Nomor HP sudah terdaftar!' },
        { status: 400 }
      )
    }

    const user = await db.user.create({
      data: {
        name,
        phone,
        pin,
        role: 'Agen'
      }
    })

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        phone: user.phone,
        role: user.role,
        pin: user.pin
      }
    })
  } catch (error) {
    console.error('Register error:', error)
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat mendaftar' },
      { status: 500 }
    )
  }
}
