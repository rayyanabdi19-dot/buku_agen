import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { phone, pin } = await request.json()

    if (!phone || !pin) {
      return NextResponse.json(
        { success: false, message: 'Nomor HP dan PIN harus diisi!' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({
      where: { phone }
    })

    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Nomor HP atau PIN salah!' },
        { status: 401 }
      )
    }

    if (user.pin !== pin) {
      return NextResponse.json(
        { success: false, message: 'Nomor HP atau PIN salah!' },
        { status: 401 }
      )
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        phone: user.phone,
        role: user.role,
        pin: user.pin
      }
    })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat login' },
      { status: 500 }
    )
  }
}
