# Deployment Steps ke Vercel

## Langkah 1: Persiapan Database Cloud

### Opsi Tercepat: Vercel Postgres

1. Push code ke GitHub/GitLab/Bitbucket
2. Import project ke Vercel
3. Di Vercel Dashboard, buka **Storage** → **Create Database** → **Postgres**
4. Klik **Create** dan tunggu database ready
5. Copy `DATABASE_URL` dari settings

### Alternatif: Neon (Free Tier)

```bash
# Install Neon CLI
npm install -g neonctl

# Login
neonctl auth login

# Buat project
neonctl projects create --name buku-agen --region aws-ap-southeast-1

# Copy connection string
neonctl connection-string <project-id>
```

## Langkah 2: Update Project untuk PostgreSQL

### Install PostgreSQL Client

```bash
bun add pg
bun add -D @types/pg
```

### Update Prisma Schema

Edit `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "postgresql"  // Ubah dari "sqlite" ke "postgresql"
  url      = env("DATABASE_URL")
}
```

## Langkah 3: Setup Environment Variables

### Di Local Development (.env.local)

```bash
DATABASE_URL="postgresql://user:pass@host:5432/db?sslmode=require"
```

### Di Vercel Dashboard

1. Buka **Settings** → **Environment Variables**
2. Tambahkan:
   - Name: `DATABASE_URL`
   - Value: Connection string dari database cloud Anda
   - Environments: Production, Preview, Development

## Langkah 4: Generate Prisma & Push Schema

### Di Local dengan PostgreSQL connection:

```bash
# Generate Prisma Client
bun run db:generate

# Push schema ke database
bun run db:push
```

### Jika ingin menggunakan migrations (recommended untuk production):

```bash
# Buat migration
bun prisma migrate dev --name init

# Apply migration di production
bun prisma migrate deploy
```

## Langkah 5: Update vercel.json (Sudah disediakan)

File `vercel.json` sudah dikonfigurasi:

```json
{
  "buildCommand": "prisma generate && next build",
  "devCommand": "next dev",
  "installCommand": "bun install",
  "framework": "nextjs",
  "regions": ["sin1"]
}
```

## Langkah 6: Deploy ke Vercel

### Method 1: Dari Vercel Dashboard (Recommended)

1. Buka [vercel.com/new](https://vercel.com/new)
2. Import repository Git Anda
3. Vercel akan auto-detect Next.js
4. Configure:
   - **Framework Preset**: Next.js
   - **Build Command**: `prisma generate && next build`
   - **Output Directory**: `.next`
5. Pada Environment Variables, tambahkan `DATABASE_URL`
6. Klik **Deploy**

### Method 2: Dari CLI

```bash
# Install Vercel CLI
bun add -g vercel

# Login
vercel login

# Deploy (preview)
vercel

# Deploy ke production
vercel --prod
```

## Langkah 7: Verifikasi

Setelah deployment selesai:

1. ✅ Buka URL production dari Vercel
2. ✅ Test register akun baru
3. ✅ Test login
4. ✅ Test buka shift
5. ✅ Test transaksi (tarik/setor/transfer)
6. ✅ Test tutup laci
7. ✅ Test laporan

## Troubleshooting

### Masalah: Build Error "Cannot find module '@prisma/client'"

**Solusi**: Pastikan build command menyertakan `prisma generate`:

```json
"buildCommand": "prisma generate && next build"
```

### Masalah: "SSL connection is required"

**Solusi**: Tambahkan `?sslmode=require` di DATABASE_URL:

```
postgresql://user:pass@host:5432/db?sslmode=require
```

### Masalah: Connection timeout

**Solusi**: Tambahkan connection pool:

```
postgresql://user:pass@host:5432/db?sslmode=require&connection_limit=10&pool_timeout=20
```

### Masalah: Prisma Client tidak tergenerate di production

**Solusi**: Tambahkan script postinstall di package.json:

```json
"scripts": {
  "postinstall": "prisma generate"
}
```

## Checklist Sebelum Deploy

- [ ] Code sudah push ke Git repository
- [ ] PostgreSQL database sudah dibuat
- [ ] DATABASE_URL sudah diset di Vercel Environment Variables
- [ ] Prisma schema sudah diubah ke `provider = "postgresql"`
- [ ] Package `pg` sudah ditambahkan ke dependencies
- [ ] Build command sudah diset ke `prisma generate && next build`
- [ ] Test semua fitur di local dengan PostgreSQL
- [ ] Commit dan push semua changes

## Domain Custom (Opsional)

1. Buka **Settings** → **Domains** di Vercel Dashboard
2. Tambahkan domain Anda (misal: `buku-agen.com`)
3. Ikuti instruksi untuk mengkonfigurasi DNS records
4. Tunggu SSL certificate tergenerate (otomatis)
