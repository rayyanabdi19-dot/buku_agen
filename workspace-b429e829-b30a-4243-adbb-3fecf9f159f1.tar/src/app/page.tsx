'use client'

import { useState, useEffect } from 'react'
import {
  LayoutDashboard,
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  History,
  User,
  LogOut,
  Plus,
  FileText,
  TrendingUp,
  Store,
  X,
  Share2,
  Printer,
  ChevronRight,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  Settings,
  CreditCard,
  Search,
  Calendar,
  Layers,
  PlusCircle,
  Clock,
  Database,
  UserPlus,
  KeyRound,
  Download,
  FileDown,
  ChevronLeft
} from 'lucide-react'

// --- Utils & Formatter ---
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0
  }).format(amount)
}

const formatDate = (date: string) => {
  return new Intl.DateTimeFormat('id-ID', {
    dateStyle: 'long' as const,
    timeStyle: 'short' as const
  }).format(new Date(date))
}

interface User {
  id: string
  name: string
  phone: string
  role: string
  pin: string
}

interface Transaction {
  id: string
  type: string
  amount: number
  fee: number
  timestamp: string
  customerName: string
  target: string
  status: string
}

interface DailyStatus {
  id: string
  userId: string
  date: string
  cashStart: number
  bankStart: number
  timeOpen: string
  timeClose?: string | null
  status: string
}

export default function Home() {
  // --- State Management ---
  const [user, setUser] = useState<User | null>(null)
  const [currentPage, setCurrentPage] = useState('login')
  const [authMode, setAuthMode] = useState('login')

  const [dailyStatus, setDailyStatus] = useState<DailyStatus | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [balance, setBalance] = useState({ cash: 0, bank: 0 })
  const [notifications, setNotifications] = useState<{ id: number; message: string }[]>([])
  const [searchQuery, setSearchQuery] = useState('')

  // Load admin settings from localStorage on mount
  const [adminSettings, setAdminSettings] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('adminSettings')
      if (saved) {
        return JSON.parse(saved)
      }
    }
    return {
      tarik: { fee: 5000, step: 1000000 },
      setor: { fee: 5000, step: 1000000 },
      transfer: { fee: 6500, step: 1000000 }
    }
  })

  const [showTransactionModal, setShowTransactionModal] = useState<string | null>(null)
  const [showTopupModal, setShowTopupModal] = useState(false)
  const [showReceipt, setShowReceipt] = useState<Transaction | null>(null)
  const [showCloseDrawerModal, setShowCloseDrawerModal] = useState(false)

  // Calculate fee based on step multiplier
  const calculateFee = (amount: number, type: string) => {
    const config = adminSettings[type as keyof typeof adminSettings]
    if (!config) return 0

    const { fee, step } = config
    if (step === 0) return fee

    // Calculate multiplier, round up
    const multiplier = Math.ceil(amount / step)
    return multiplier * fee
  }

  // Save admin settings to localStorage
  const updateAdminSettings = (newSettings: typeof adminSettings) => {
    setAdminSettings(newSettings)
    if (typeof window !== 'undefined') {
      localStorage.setItem('adminSettings', JSON.stringify(newSettings))
    }
  }

  // --- Auth Logic ---
  const handleLogin = async (phone: string, pin: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, pin })
      })
      const data = await res.json()

      if (data.success) {
        setUser(data.user)
        addNotification(`Selamat datang, ${data.user.name}`)
        // Pass user data directly to avoid timing issue
        await checkDailyStatusWithData(data.user.id)
      } else {
        addNotification(data.message || 'Nomor HP atau PIN salah!')
      }
    } catch (error) {
      addNotification('Terjadi kesalahan saat login')
    }
  }

  const handleRegister = async (data: { name: string; phone: string; pin: string }) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      const responseData = await res.json()

      if (responseData.success) {
        addNotification('Pendaftaran Berhasil! Silakan Login.')
        setAuthMode('login')
      } else {
        addNotification(responseData.message || 'Pendaftaran gagal!')
      }
    } catch (error) {
      addNotification('Terjadi kesalahan saat mendaftar')
    }
  }

  const checkDailyStatusWithData = async (userId: string) => {
    try {
      const today = new Date().toISOString().split('T')[0]
      const res = await fetch(`/api/daily-status?userId=${userId}&date=${today}`)
      const data = await res.json()

      if (data.success && data.dailyStatus) {
        setDailyStatus(data.dailyStatus)
        setBalance({ cash: data.cashBalance, bank: data.bankBalance })
        setCurrentPage('dashboard')
        await loadTransactions(data.dailyStatus.id)
      } else {
        setCurrentPage('open-store')
      }
    } catch (error) {
      console.error('Error checking daily status:', error)
      addNotification('Terjadi kesalahan saat memeriksa status harian')
    }
  }

  const checkDailyStatus = async () => {
    if (!user) return

    await checkDailyStatusWithData(user.id)
  }

  const loadTransactions = async (dailyStatusId: string) => {
    try {
      const res = await fetch(`/api/transactions?dailyStatusId=${dailyStatusId}`)
      const data = await res.json()

      if (data.success) {
        setTransactions(data.transactions)
      }
    } catch (error) {
      console.error('Error loading transactions:', error)
    }
  }

  const handleOpenStore = async (data: { cashStart: number; bankStart: number }) => {
    if (!user) return

    try {
      const today = new Date().toISOString().split('T')[0]
      const res = await fetch('/api/daily-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          date: today,
          cashStart: data.cashStart,
          bankStart: data.bankStart
        })
      })
      const responseData = await res.json()

      if (responseData.success) {
        setDailyStatus(responseData.dailyStatus)
        setBalance({ cash: data.cashStart, bank: data.bankStart })
        setCurrentPage('dashboard')
        await loadTransactions(responseData.dailyStatus.id)
      } else {
        addNotification('Gagal membuka shift!')
      }
    } catch (error) {
      addNotification('Terjadi kesalahan saat membuka shift')
    }
  }

  const handleCloseDrawer = async () => {
    if (!user || !dailyStatus) return

    try {
      const res = await fetch('/api/daily-status/close', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dailyStatusId: dailyStatus.id,
          cashEnd: balance.cash,
          bankEnd: balance.bank
        })
      })
      const responseData = await res.json()

      if (responseData.success) {
        addNotification('Laci berhasil ditutup!')
        setShowCloseDrawerModal(false)
        setDailyStatus(null)
        setBalance({ cash: 0, bank: 0 })
        setTransactions([])
        setUser(null)
        setCurrentPage('login')
      } else {
        addNotification(responseData.message || 'Gagal menutup laci!')
      }
    } catch (error) {
      addNotification('Terjadi kesalahan saat menutup laci')
    }
  }

  const handleTopup = async (data: { type: string; amount: number; source: string }) => {
    if (!user || !dailyStatus) return

    try {
      const res = await fetch('/api/transactions/topup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          dailyStatusId: dailyStatus.id,
          type: data.type,
          amount: data.amount,
          source: data.source
        })
      })
      const responseData = await res.json()

      if (responseData.success) {
        const { transaction, cashBalance, bankBalance } = responseData

        if (data.type === 'CASH') {
          setBalance(prev => ({ ...prev, cash: cashBalance }))
        } else {
          setBalance(prev => ({ ...prev, bank: bankBalance }))
        }

        setTransactions([transaction, ...transactions])
        addNotification(`Top Up ${data.type} Berhasil!`)
        setShowTopupModal(false)
      } else {
        addNotification('Gagal melakukan top up!')
      }
    } catch (error) {
      addNotification('Terjadi kesalahan saat top up')
    }
  }

  const handleTransaction = async (
    type: string,
    amount: number,
    fee: number,
    data: { customerName: string; target: string }
  ) => {
    if (!user || !dailyStatus) return

    try {
      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          dailyStatusId: dailyStatus.id,
          type,
          amount,
          fee,
          customerName: data.customerName,
          target: data.target
        })
      })
      const responseData = await res.json()

      if (responseData.success) {
        const { transaction, cashBalance, bankBalance } = responseData

        setTransactions([transaction, ...transactions])
        setBalance({ cash: cashBalance, bank: bankBalance })

        addNotification(`Transaksi ${type} Berhasil!`)
        setShowTransactionModal(null)
        setShowReceipt(transaction)
      } else {
        addNotification('Gagal melakukan transaksi!')
      }
    } catch (error) {
      addNotification('Terjadi kesalahan saat transaksi')
    }
  }

  const addNotification = (msg: string) => {
    const id = Date.now()
    setNotifications([{ id, message: msg }, ...notifications])
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id))
    }, 3000)
  }

  // --- Export Functions ---
  const exportToExcel = () => {
    let csvContent = 'data:text/csv;charset=utf-8,'
    csvContent += 'ID Transaksi,Waktu,Tipe,Nasabah,Nominal,Admin Fee,Tujuan\n'

    transactions.forEach(tx => {
      const row = [
        tx.id,
        new Date(tx.timestamp).toLocaleString(),
        tx.type,
        tx.customerName,
        tx.amount,
        tx.fee,
        tx.target
      ].join(',')
      csvContent += row + '\n'
    })

    const encodedUri = encodeURI(csvContent)
    const link = document.createElement('a')
    link.setAttribute('href', encodedUri)
    link.setAttribute('download', `Laporan_Agen_${new Date().toISOString().split('T')[0]}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    addNotification('Laporan Excel (CSV) berhasil diunduh')
  }

  const exportToPDF = () => {
    window.print()
  }

  // --- Shared Components ---
  const BottomNav = () => (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 px-6 py-4 flex justify-between items-center z-50 rounded-t-3xl shadow-[0_-4px_20px_rgba(0,0,0,0.05)] print:hidden">
      {[
        { id: 'dashboard', label: 'Beranda', icon: <LayoutDashboard size={24} /> },
        { id: 'cashbook', label: 'Buku Kas', icon: <Wallet size={24} /> },
        { id: 'report', label: 'Laporan', icon: <FileText size={24} /> },
        { id: 'account', label: 'Akun', icon: <User size={24} /> },
        { id: 'settings', label: 'Pengaturan', icon: <Settings size={24} /> }
      ].map(item => (
        <button
          key={item.id}
          onClick={() => setCurrentPage(item.id)}
          className={`flex flex-col items-center gap-1 transition-all ${currentPage === item.id ? 'text-blue-600' : 'text-slate-400'}`}
        >
          {item.icon}
          <span className="text-[10px] font-bold">{item.label}</span>
        </button>
      ))}
    </nav>
  )

  const SectionHeader = ({ title, showBack = false }: { title: string; showBack?: boolean }) => (
    <div className="bg-blue-600 pt-12 pb-8 px-6 rounded-b-[32px] mb-6 shadow-lg print:bg-white print:text-slate-800 print:shadow-none print:pt-4">
      <div className="flex items-center gap-4">
        {showBack && (
          <button
            onClick={() => setCurrentPage('dashboard')}
            className="p-2 bg-white/20 rounded-full text-white print:hidden hover:bg-white/30 transition-all"
          >
            <ChevronLeft size={24} />
          </button>
        )}
        <h2 className="text-xl font-bold text-white print:text-center print:text-2xl print:text-slate-900 flex-1">{title}</h2>
      </div>
      <p className="hidden print:block text-center text-xs text-slate-500 font-bold mt-2 uppercase tracking-widest">
        Dicetak pada: {formatDate(new Date().toISOString())}
      </p>
    </div>
  )

  // --- Page Views ---
  const ReportPage = () => {
    const stats = transactions.reduce(
      (acc, tx) => {
        if (tx.type === 'TOPUP') acc.topup += tx.amount
        else {
          acc.adminFee += tx.fee
          acc.volume += tx.amount
          if (tx.type === 'TARIK') acc.cashOut += tx.amount
          if (tx.type === 'SETOR' || tx.type === 'TRANSFER') acc.cashIn += tx.amount
        }
        return acc
      },
      { adminFee: 0, volume: 0, cashIn: 0, cashOut: 0, topup: 0 }
    )

    const filteredTransactions = transactions.filter(
      tx =>
        tx.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.type.toLowerCase().includes(searchQuery.toLowerCase())
    )

    return (
      <div className="min-h-screen bg-slate-50 pb-24">
        <SectionHeader title="Laporan Keuangan" showBack={true} />

        <div className="px-6 space-y-6">
          <div className="grid grid-cols-2 gap-4 print:grid-cols-4">
            <div className="bg-white p-5 rounded-[24px] border border-slate-100 shadow-sm print:border-slate-300">
              <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Total Admin Fee</p>
              <h4 className="text-lg font-black text-blue-600">{formatCurrency(stats.adminFee)}</h4>
            </div>
            <div className="bg-white p-5 rounded-[24px] border border-slate-100 shadow-sm print:border-slate-300">
              <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Volume TRX</p>
              <h4 className="text-lg font-black text-slate-800">{formatCurrency(stats.volume)}</h4>
            </div>
          </div>

          <div className="flex gap-3 print:hidden">
            <button
              onClick={exportToExcel}
              className="flex-1 bg-green-50 text-green-600 p-4 rounded-2xl flex items-center justify-center gap-2 font-black text-[10px] uppercase tracking-widest border border-green-100"
            >
              <FileDown size={18} /> Excel (CSV)
            </button>
            <button
              onClick={exportToPDF}
              className="flex-1 bg-red-50 text-red-600 p-4 rounded-2xl flex items-center justify-center gap-2 font-black text-[10px] uppercase tracking-widest border border-red-100"
            >
              <Printer size={18} /> Simpan PDF
            </button>
          </div>

          <div className="relative print:hidden">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              placeholder="Cari Nasabah atau Jenis Layanan..."
              className="w-full pl-12 p-4 bg-white border border-slate-100 rounded-2xl text-xs font-bold focus:ring-2 focus:ring-blue-500 shadow-sm"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              suppressHydrationWarning
            />
          </div>

          <div className="bg-white rounded-[32px] overflow-hidden border border-slate-100 shadow-sm print:rounded-none print:border-none print:shadow-none">
            <div className="p-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
              <h4 className="font-black text-slate-800 text-[10px] uppercase tracking-widest">Detail Riwayat</h4>
              <span className="text-[9px] font-bold text-slate-400 uppercase">{filteredTransactions.length} Transaksi</span>
            </div>
            <div className="divide-y divide-slate-50">
              {filteredTransactions.map(tx => (
                <div key={tx.id} className="p-5 flex justify-between items-start hover:bg-slate-50 transition-colors">
                  <div className="space-y-1">
                    <p className="text-xs font-black text-slate-800 uppercase tracking-tight">{tx.customerName}</p>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[8px] font-black px-1.5 py-0.5 rounded-md uppercase ${
                          tx.type === 'TARIK' ? 'bg-orange-100 text-orange-600' : tx.type === 'TOPUP' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'
                        }`}
                      >
                        {tx.type}
                      </span>
                      <span className="text-[8px] text-slate-300 font-bold">{formatDate(tx.timestamp).split(',')[1]}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-xs font-black ${tx.type === 'TARIK' ? 'text-red-500' : 'text-green-600'}`}>
                      {tx.type === 'TARIK' ? '-' : '+'}
                      {formatCurrency(tx.amount)}
                    </p>
                    {tx.fee > 0 && <p className="text-[8px] font-bold text-blue-400 mt-1">Fee: {formatCurrency(tx.fee)}</p>}
                  </div>
                </div>
              ))}
              {filteredTransactions.length === 0 && (
                <div className="p-12 text-center text-slate-400 italic text-[10px] uppercase font-bold tracking-widest">
                  Tidak ada data ditemukan
                </div>
              )}
            </div>
          </div>
        </div>
        <BottomNav />
      </div>
    )
  }

  const AuthPage = () => {
    const [formData, setFormData] = useState({ phone: '', pin: '', name: '' })
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 animate-in fade-in duration-500">
        <div className="w-full max-w-md bg-white rounded-[40px] shadow-2xl p-10 border border-slate-100">
          <div className="text-center mb-10">
            <div className="bg-blue-600 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-blue-100 rotate-3">
              <Smartphone className="text-white w-10 h-10 -rotate-3" />
            </div>
            <h1 className="text-3xl font-black text-slate-800 tracking-tight uppercase">Buku Agen</h1>
            <p className="text-slate-400 font-bold text-xs uppercase tracking-widest mt-1">
              {authMode === 'login' ? 'Masuk ke Akun Anda' : 'Daftar Akun Baru'}
            </p>
          </div>
          <div className="space-y-4">
            {authMode === 'register' && (
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Nama Lengkap</label>
                <input
                  type="text"
                  autoComplete="name"
                  className="w-full p-5 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-blue-500 font-bold"
                  placeholder="Contoh: Agen Sentosa"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  suppressHydrationWarning
                />
              </div>
            )}
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Nomor HP</label>
              <input
                type="tel"
                autoComplete="tel"
                className="w-full p-5 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-blue-500 font-bold"
                placeholder="08xxxxxxxxxx"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                suppressHydrationWarning
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">PIN Transaksi (6 Digit)</label>
              <input
                type="password"
                autoComplete="off"
                maxLength={6}
                className="w-full p-5 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-blue-500 tracking-[0.5em] text-center font-black text-xl"
                placeholder="••••••"
                value={formData.pin}
                onChange={e => setFormData({ ...formData, pin: e.target.value })}
                suppressHydrationWarning
              />
            </div>
            <button
              onClick={() => (authMode === 'login' ? handleLogin(formData.phone, formData.pin) : handleRegister(formData))}
              className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-100 active:scale-95 transition-all text-sm uppercase tracking-widest mt-4"
              suppressHydrationWarning
            >
              {authMode === 'login' ? 'Masuk Sekarang' : 'Daftar Sekarang'}
            </button>
          </div>
          <div className="mt-8 text-center">
            <p className="text-slate-400 text-xs font-bold uppercase tracking-tight">
              {authMode === 'login' ? 'Belum punya akun?' : 'Sudah punya akun?'}
            </p>
            <button
              onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
              className="text-blue-600 font-black text-xs uppercase tracking-widest mt-2 hover:underline"
              suppressHydrationWarning
            >
              {authMode === 'login' ? 'Daftar Menu Agen' : 'Kembali Ke Login'}
            </button>
          </div>
        </div>
      </div>
    )
  }

  const TopupModal = () => {
    const [step, setStep] = useState(1)
    const [formData, setFormData] = useState({ type: 'CASH', amount: '', source: '', note: '' })
    const [pin, setPin] = useState('')
    if (!showTopupModal) return null

    const handleConfirm = () => {
      if (pin === user?.pin) {
        handleTopup({
          type: formData.type,
          amount: parseFloat(formData.amount) || 0,
          source: formData.source
        })
      } else {
        addNotification('PIN SALAH!')
        setPin('')
      }
    }

    return (
      <div className="fixed inset-0 z-[150] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
        <div className="bg-white w-full max-w-lg rounded-t-[40px] sm:rounded-[40px] overflow-hidden animate-in slide-in-from-bottom duration-300 shadow-2xl">
          <div className="bg-slate-900 p-8 flex justify-between items-center text-white">
            <div className="flex items-center gap-3">
              <PlusCircle className="text-blue-400" />
              <h3 className="text-xl font-black uppercase tracking-tight">Top Up Saldo</h3>
            </div>
            <button onClick={() => { setShowTopupModal(false); setStep(1) }} className="p-2 bg-white/10 rounded-full">
              <X size={20} />
            </button>
          </div>
          <div className="p-8 space-y-6">
            {step === 1 ? (
              <>
                <div className="flex bg-slate-100 p-1 rounded-2xl">
                  <button
                    onClick={() => setFormData({ ...formData, type: 'CASH' })}
                    className={`flex-1 py-3 rounded-xl font-black text-xs transition-all ${formData.type === 'CASH' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
                  >
                    KAS LACI
                  </button>
                  <button
                    onClick={() => setFormData({ ...formData, type: 'BANK' })}
                    className={`flex-1 py-3 rounded-xl font-black text-xs transition-all ${formData.type === 'BANK' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
                  >
                    REKENING
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Nominal Top Up</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-slate-300 text-2xl">Rp</span>
                      <input
                        type="number"
                        className="w-full pl-16 p-5 bg-slate-50 border-none rounded-2xl text-3xl font-black text-slate-800"
                        placeholder="0"
                        value={formData.amount}
                        onChange={e => setFormData({ ...formData, amount: e.target.value })}
                        suppressHydrationWarning
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Sumber Dana</label>
                    <input
                      type="text"
                      className="w-full p-5 bg-slate-50 border-none rounded-2xl font-black text-slate-800 uppercase text-sm"
                      placeholder="Contoh: OWNER / SETOR TUNAI / MODAL"
                      value={formData.source}
                      onChange={e => setFormData({ ...formData, source: e.target.value })}
                      suppressHydrationWarning
                    />
                  </div>
                </div>

                <button
                  onClick={() => setStep(2)}
                  disabled={!formData.amount || parseFloat(formData.amount) <= 0 || !formData.source}
                  className="w-full py-5 rounded-2xl font-black text-white bg-blue-600 shadow-xl disabled:bg-slate-300 uppercase tracking-widest text-xs"
                >
                  LANJUTKAN
                </button>
              </>
            ) : (
              <div className="text-center space-y-6 py-4">
                <div className="bg-blue-50 p-6 rounded-[32px] text-left border border-blue-100">
                  <p className="text-[10px] font-black text-blue-400 uppercase mb-2">Konfirmasi Top Up</p>
                  <div className="flex justify-between items-end">
                    <h4 className="text-2xl font-black text-slate-800 tracking-tight">{formatCurrency(parseFloat(formData.amount) || 0)}</h4>
                    <span className="text-[9px] font-black bg-blue-200 text-blue-700 px-2 py-1 rounded-md uppercase">{formData.source}</span>
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Masukkan PIN Transaksi</label>
                  <input
                    type="password"
                    autoComplete="off"
                    maxLength={6}
                    className="w-full p-5 bg-slate-100 border-none rounded-2xl text-center text-3xl tracking-[1em] font-black"
                    placeholder="••••••"
                    value={pin}
                    onChange={e => setPin(e.target.value)}
                    suppressHydrationWarning
                  />
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep(1)} className="flex-1 py-4 font-black text-slate-400 text-xs uppercase tracking-widest">
                    Kembali
                  </button>
                  <button onClick={handleConfirm} className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg">
                    Simpan
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  const CloseDrawerModal = () => {
    if (!showCloseDrawerModal || !dailyStatus) return null

    // Calculate today's summary
    const todayStats = transactions.reduce(
      (acc, tx) => {
        if (tx.type === 'TOPUP') {
          acc.topup += tx.amount
        } else {
          acc.adminFee += tx.fee
          acc.volume += tx.amount
          if (tx.type === 'TARIK') acc.cashOut += tx.amount
          if (tx.type === 'SETOR' || tx.type === 'TRANSFER') acc.cashIn += tx.amount
        }
        return acc
      },
      { adminFee: 0, volume: 0, cashIn: 0, cashOut: 0, topup: 0 }
    )

    const cashDiff = balance.cash - dailyStatus.cashStart
    const bankDiff = balance.bank - dailyStatus.bankStart

    return (
      <div className="fixed inset-0 z-[160] bg-black/70 backdrop-blur-md flex items-center justify-center p-6">
        <div className="bg-white w-full max-w-md rounded-[40px] overflow-hidden animate-in slide-in-from-bottom duration-300 shadow-2xl">
          <div className="bg-slate-900 p-6 flex justify-between items-center text-white">
            <div className="flex items-center gap-3">
              <LogOut className="text-red-400" />
              <h3 className="text-xl font-black uppercase tracking-tight">Tutup Laci</h3>
            </div>
            <button onClick={() => setShowCloseDrawerModal(false)} className="p-2 bg-white/10 rounded-full">
              <X size={20} />
            </button>
          </div>

          <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
            <div className="bg-red-50 p-5 rounded-2xl border border-red-100">
              <h4 className="text-[10px] font-black text-red-600 uppercase tracking-widest mb-3">Ringkasan Hari Ini</h4>
              <div className="space-y-2 text-[10px]">
                <div className="flex justify-between">
                  <span className="text-slate-600">Tanggal:</span>
                  <span className="font-black text-slate-800">{new Date(dailyStatus.date).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Total Transaksi:</span>
                  <span className="font-black text-slate-800">{transactions.length}x</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Volume Transaksi:</span>
                  <span className="font-black text-slate-800">{formatCurrency(todayStats.volume)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Total Admin Fee:</span>
                  <span className="font-black text-green-600">{formatCurrency(todayStats.adminFee)}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                <p className="text-[9px] font-black text-blue-400 uppercase mb-2">KAS LACI</p>
                <div className="space-y-1 text-[10px]">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Awal:</span>
                    <span className="font-black text-slate-800">{formatCurrency(dailyStatus.cashStart)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Akhir:</span>
                    <span className={`font-black ${cashDiff >= 0 ? 'text-green-600' : 'text-red-500'}`}>{formatCurrency(balance.cash)}</span>
                  </div>
                  <div className={`border-t pt-1 flex justify-between ${cashDiff >= 0 ? 'border-green-200' : 'border-red-200'}`}>
                    <span className="text-slate-600">Selisih:</span>
                    <span className={`font-black ${cashDiff >= 0 ? 'text-green-600' : 'text-red-500'}`}>{formatCurrency(Math.abs(cashDiff))}</span>
                  </div>
                </div>
              </div>
              <div className="bg-purple-50 p-4 rounded-2xl border border-purple-100">
                <p className="text-[9px] font-black text-purple-400 uppercase mb-2">REKENING BANK</p>
                <div className="space-y-1 text-[10px]">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Awal:</span>
                    <span className="font-black text-slate-800">{formatCurrency(dailyStatus.bankStart)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Akhir:</span>
                    <span className={`font-black ${bankDiff >= 0 ? 'text-green-600' : 'text-red-500'}`}>{formatCurrency(balance.bank)}</span>
                  </div>
                  <div className={`border-t pt-1 flex justify-between ${bankDiff >= 0 ? 'border-green-200' : 'border-red-200'}`}>
                    <span className="text-slate-600">Selisih:</span>
                    <span className={`font-black ${bankDiff >= 0 ? 'text-green-600' : 'text-red-500'}`}>{formatCurrency(Math.abs(bankDiff))}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 p-5 rounded-2xl border border-yellow-100">
              <p className="text-[10px] font-black text-yellow-600 uppercase tracking-widest mb-3 flex items-center gap-2">
                <AlertCircle size={14} /> Peringatan
              </p>
              <div className="text-[10px] text-slate-700 space-y-1">
                <p>• Pastikan saldo kas laci dan bank sudah sesuai</p>
                <p>• Setelah ditutup, shift tidak bisa dibuka kembali</p>
                <p>• Anda akan keluar otomatis setelah menutup laci</p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowCloseDrawerModal(false)}
                className="flex-1 py-4 font-black text-slate-400 text-xs uppercase tracking-widest bg-white border border-slate-200 rounded-2xl"
                suppressHydrationWarning
              >
                Batal
              </button>
              <button
                onClick={handleCloseDrawer}
                className="flex-[2] bg-red-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg hover:bg-red-500 transition-colors"
                suppressHydrationWarning
              >
                Tutup Laci Sekarang
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const TransactionModal = () => {
    const [amount, setAmount] = useState('')
    const [manualFee, setManualFee] = useState<number | null>(null)
    const [custName, setCustName] = useState('')
    const [target, setTarget] = useState('')
    if (!showTransactionModal) return null
    const type = showTransactionModal.toLowerCase()
    const config: { title: string; color: string; bg: string; icon: React.ReactNode } = {
      tarik: { title: 'Tarik Tunai', color: 'text-orange-600', bg: 'bg-orange-50', icon: <ArrowDownLeft /> },
      setor: { title: 'Setor Tunai', color: 'text-green-600', bg: 'bg-green-50', icon: <ArrowUpRight /> },
      transfer: { title: 'Transfer Bank', color: 'text-blue-600', bg: 'bg-blue-50', icon: <CreditCard /> }
    }[type]

    // Auto-calculate fee based on step multiplier
    const parsedAmount = parseFloat(amount || 0)
    const autoFee = parsedAmount > 0 ? calculateFee(parsedAmount, type) : (adminSettings[type]?.fee || 0)
    const currentFee = manualFee !== null ? manualFee : autoFee
    return (
      <div className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
        <div className="bg-white w-full max-w-lg rounded-t-[40px] sm:rounded-[40px] overflow-hidden animate-in slide-in-from-bottom duration-300 shadow-2xl">
          <div className={`${config.bg} p-8 flex justify-between items-center`}>
            <div className="flex items-center gap-3">
              <span className={config.color}>{config.icon}</span>
              <h3 className={`text-xl font-black uppercase tracking-tight ${config.color}`}>{config.title}</h3>
            </div>
            <button onClick={() => setShowTransactionModal(null)} className="p-2 bg-white/50 rounded-full">
              <X size={20} />
            </button>
          </div>
          <div className="p-8 space-y-6">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Nominal</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-slate-300 text-2xl">Rp</span>
                <input
                  type="number"
                  className="w-full pl-16 p-5 bg-slate-50 border-none rounded-2xl text-3xl font-black text-slate-800"
                  placeholder="0"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  suppressHydrationWarning
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Admin Fee</label>
                <input
                  type="number"
                  className="w-full p-4 bg-blue-50/50 border-none rounded-2xl font-black text-blue-600"
                  value={currentFee}
                  onChange={e => setManualFee(parseInt(e.target.value) || 0)}
                  suppressHydrationWarning
                />
                {manualFee === null && parsedAmount > 0 && (
                  <p className="text-[8px] text-slate-400 font-bold mt-1">
                    {parsedAmount} ÷ {formatCurrency(adminSettings[type]?.step || 0)} = {(parsedAmount / (adminSettings[type]?.step || 0)).toFixed(2)} → {Math.ceil(parsedAmount / (adminSettings[type]?.step || 0))} × {formatCurrency(adminSettings[type]?.fee || 0)}
                  </p>
                )}
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Total</label>
                <div className="w-full p-4 bg-slate-100 border-none rounded-2xl font-black text-slate-500 h-[52px] flex items-center">
                  {formatCurrency((parseFloat(amount || 0) + currentFee))}
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <input
                type="text"
                className="w-full p-4 bg-slate-50 border-none rounded-2xl font-bold uppercase text-xs"
                placeholder="NAMA NASABAH"
                value={custName}
                onChange={e => setCustName(e.target.value)}
                suppressHydrationWarning
              />
              <input
                type="text"
                className="w-full p-4 bg-slate-50 border-none rounded-2xl font-bold uppercase text-xs"
                placeholder="TUJUAN / NO. REK"
                value={target}
                onChange={e => setTarget(e.target.value)}
                suppressHydrationWarning
              />
            </div>
            <button
              onClick={() => handleTransaction(showTransactionModal.toUpperCase(), parseFloat(amount) || 0, currentFee, { customerName: custName, target })}
              disabled={!amount || parseFloat(amount) <= 0}
              className={`w-full py-5 rounded-2xl font-black text-lg text-white shadow-2xl ${!amount || parseFloat(amount) <= 0 ? 'bg-slate-300' : 'bg-blue-600 shadow-blue-200'}`}
            >
              SIMPAN TRX
            </button>
          </div>
        </div>
      </div>
    )
  }

  const SettingsPage = () => (
    <div className="min-h-screen bg-slate-50 pb-24">
      <SectionHeader title="Pengaturan Biaya" showBack={true} />
      <div className="px-6 space-y-4">
        <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
          <h3 className="font-black text-slate-800 text-sm uppercase tracking-widest mb-6 flex items-center gap-2">
            <Settings size={18} /> Biaya Admin
          </h3>

          {[
            { key: 'tarik', title: 'Tarik Tunai', color: 'text-orange-600', bgColor: 'bg-orange-50' },
            { key: 'setor', title: 'Setor Tunai', color: 'text-green-600', bgColor: 'bg-green-50' },
            { key: 'transfer', title: 'Transfer Bank', color: 'text-blue-600', bgColor: 'bg-blue-50' }
          ].map(item => (
            <div key={item.key} className="mb-6 last:mb-0">
              <div className={`p-5 rounded-2xl ${item.bgColor} mb-4`}>
                <h4 className={`font-black text-xs uppercase tracking-widest ${item.color} mb-2`}>{item.title}</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 block">Fee Per Kelipatan (Rp)</label>
                    <input
                      type="number"
                      value={adminSettings[item.key as keyof typeof adminSettings].fee}
                      onChange={(e) => {
                        const newSettings = { ...adminSettings }
                        newSettings[item.key as keyof typeof adminSettings] = {
                          ...newSettings[item.key as keyof typeof adminSettings],
                          fee: parseFloat(e.target.value) || 0
                        }
                        updateAdminSettings(newSettings)
                      }}
                      className="w-full p-3 bg-white border-none rounded-xl text-lg font-black text-slate-800"
                      suppressHydrationWarning
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 block">Kelipatan (Rp)</label>
                    <input
                      type="number"
                      value={adminSettings[item.key as keyof typeof adminSettings].step}
                      onChange={(e) => {
                        const newSettings = { ...adminSettings }
                        newSettings[item.key as keyof typeof adminSettings] = {
                          ...newSettings[item.key as keyof typeof adminSettings],
                          step: parseFloat(e.target.value) || 0
                        }
                        updateAdminSettings(newSettings)
                      }}
                      className="w-full p-3 bg-white border-none rounded-xl text-lg font-black text-slate-800"
                      suppressHydrationWarning
                    />
                  </div>
                </div>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl">
                <p className="text-[9px] text-slate-600 font-bold text-center">
                  Rumus: Math.ceil(Transaksi / Kelipatan) × Fee = Biaya Admin
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-blue-50 p-5 rounded-2xl border border-blue-100">
          <h4 className="font-black text-xs uppercase tracking-widest text-blue-600 mb-3 flex items-center gap-2">
            <TrendingUp size={16} /> Contoh Perhitungan
          </h4>
          <div className="space-y-2 text-[10px] text-slate-700">
            <p><strong className="text-slate-800">Tarik:</strong> Rp 2.500.000</p>
            <p className="pl-4">→ 2.500.000 ÷ 1.000.000 = 2.5</p>
            <p className="pl-4">→ Math.ceil(2.5) = 3 kelipatan</p>
            <p className="pl-4 text-blue-600 font-black">→ 3 × Rp 5.000 = <strong>Rp 15.000</strong></p>
            <div className="h-px bg-slate-200 my-2"></div>
            <p><strong className="text-slate-800">Transfer:</strong> Rp 1.500.000</p>
            <p className="pl-4">→ 1.500.000 ÷ 1.000.000 = 1.5</p>
            <p className="pl-4">→ Math.ceil(1.5) = 2 kelipatan</p>
            <p className="pl-4 text-blue-600 font-black">→ 2 × Rp 6.500 = <strong>Rp 13.000</strong></p>
          </div>
        </div>

        <button
          onClick={() => {
            if (confirm('Kembali ke pengaturan default?')) {
              const defaultSettings = {
                tarik: { fee: 5000, step: 1000000 },
                setor: { fee: 5000, step: 1000000 },
                transfer: { fee: 6500, step: 1000000 }
              }
              updateAdminSettings(defaultSettings)
              addNotification('Pengaturan direset ke default!')
            }
          }}
          className="w-full p-4 bg-white rounded-2xl flex items-center justify-center gap-2 text-slate-500 font-black text-xs uppercase tracking-widest border border-slate-100 shadow-sm hover:bg-slate-50 transition-colors"
        >
          <Database size={16} /> Reset ke Default
        </button>
      </div>
      <BottomNav />
    </div>
  )

  const AccountPage = () => (
    <div className="min-h-screen bg-slate-50 pb-24">
      <SectionHeader title="Akun Saya" showBack={true} />
      <div className="px-6 space-y-4">
        <div className="bg-white p-6 rounded-[32px] flex items-center gap-4 border border-slate-100 shadow-sm relative overflow-hidden">
          <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
            <User size={32} />
          </div>
          <div>
            <h3 className="font-black text-slate-800 text-lg leading-tight">{user?.name}</h3>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wide">{user?.phone}</p>
          </div>
        </div>
        <button
          onClick={() => {
            setUser(null)
            setCurrentPage('login')
          }}
          className="w-full p-5 bg-white rounded-[32px] flex items-center gap-3 text-red-500 font-black text-xs uppercase tracking-widest border border-slate-100 shadow-sm"
        >
          <LogOut size={18} /> Keluar Aplikasi
        </button>
      </div>
      <BottomNav />
    </div>
  )

  return (
    <div className="app-container font-sans bg-slate-50 min-h-screen pb-24 print:pb-0 print:bg-white">
      {!user ? (
        <AuthPage />
      ) : (
        <>
          {currentPage === 'open-store' && (
            <div className="fixed inset-0 z-[100] bg-white p-8 flex items-center justify-center">
              <div className="max-w-md w-full space-y-8 text-center">
                <div className="flex flex-col items-center gap-5">
                  <div className="p-6 bg-green-100 text-green-600 rounded-[32px]">
                    <Store size={40} />
                  </div>
                  <h2 className="text-3xl font-black text-slate-800 tracking-tighter uppercase leading-none">Shift Baru</h2>
                </div>
                <div className="space-y-6 pt-4">
                  {[
                    { key: 'cashStart', label: 'Kas Laci Awal' },
                    { key: 'bankStart', label: 'Saldo Bank Awal' }
                  ].map(field => (
                    <div key={field.key} className="text-left">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block px-2">{field.label}</label>
                      <input
                        type="number"
                        className="w-full p-5 bg-slate-100 border-none rounded-[24px] text-2xl font-black text-slate-800"
                        placeholder="0"
                        onChange={e => setDailyStatus(prev => ({ ...prev, [field.key]: parseFloat(e.target.value) || 0 } as DailyStatus))}
                        suppressHydrationWarning
                      />
                    </div>
                  ))}
                  <button
                    onClick={() => handleOpenStore({ cashStart: dailyStatus?.cashStart || 0, bankStart: dailyStatus?.bankStart || 0 })}
                    className="w-full bg-green-600 text-white font-black py-5 rounded-[24px] shadow-2xl shadow-green-100 uppercase tracking-widest text-xs"
                  >
                    MULAI SHIFT
                  </button>
                </div>
              </div>
            </div>
          )}

          {currentPage === 'dashboard' && (
            <>
              <div className="bg-blue-600 pt-12 pb-24 px-6 rounded-b-[48px] shadow-xl relative overflow-hidden">
                <div className="flex justify-between items-center mb-8 relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-white">
                      <User size={24} />
                    </div>
                    <div className="text-white">
                      <p className="text-[9px] opacity-60 uppercase font-black tracking-widest">Selamat Bekerja</p>
                      <p className="font-black text-sm tracking-wide">{user?.name}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowCloseDrawerModal(true)}
                    className="flex items-center gap-2 bg-red-500 hover:bg-red-400 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg active:scale-95"
                    suppressHydrationWarning
                  >
                    <LogOut size={20} /> Tutup Laci
                  </button>
                </div>
                <div className="bg-white/10 backdrop-blur-xl rounded-[32px] p-7 border border-white/20 shadow-2xl">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <p className="text-white/60 text-[9px] font-black mb-1 uppercase tracking-[0.2em]">KAS LACI</p>
                      <h2 className="text-white text-2xl font-black tracking-tighter">{formatCurrency(balance.cash)}</h2>
                    </div>
                    <div className="border-l border-white/10 pl-6">
                      <p className="text-white/60 text-[9px] font-black mb-1 uppercase tracking-[0.2em]">BANK</p>
                      <h2 className="text-white text-2xl font-black tracking-tighter">{formatCurrency(balance.bank)}</h2>
                    </div>
                  </div>
                </div>
              </div>

              <div className="px-6 -mt-12 grid grid-cols-4 gap-3 relative z-20">
                {[
                  { id: 'tarik', label: 'Tarik', icon: <ArrowDownLeft size={24} />, color: 'text-orange-600', bg: 'bg-orange-50' },
                  { id: 'setor', label: 'Setor', icon: <ArrowUpRight size={24} />, color: 'text-green-600', bg: 'bg-green-50' },
                  { id: 'transfer', label: 'Transfer', icon: <CreditCard size={24} />, color: 'text-blue-600', bg: 'bg-blue-50' },
                  { id: 'topup', label: 'TopUp', icon: <PlusCircle size={24} />, color: 'text-slate-900', bg: 'bg-slate-100' }
                ].map(act => (
                  <button
                    key={act.id}
                    onClick={() => (act.id === 'topup' ? setShowTopupModal(true) : setShowTransactionModal(act.id))}
                    className="bg-white p-4 rounded-3xl shadow-xl flex flex-col items-center gap-3 active:scale-95 transition-all border border-slate-50"
                  >
                    <div className={`p-4 ${act.bg} ${act.color} rounded-2xl`}>{act.icon}</div>
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-tighter">{act.label}</span>
                  </button>
                ))}
              </div>

              <div className="px-6 mt-10">
                <div className="flex justify-between items-center mb-6 px-1">
                  <h3 className="font-black text-slate-800 text-xs uppercase tracking-[0.2em]">Mutasi Terakhir</h3>
                  <button onClick={() => setCurrentPage('cashbook')} className="text-blue-600 text-[10px] font-black uppercase tracking-widest">
                    Semua Mutasi
                  </button>
                </div>
                <div className="space-y-4 pb-24">
                  {transactions.slice(0, 5).map(tx => (
                    <div key={tx.id} className="bg-white p-5 rounded-[28px] flex items-center justify-between shadow-sm border border-slate-100">
                      <div className="flex items-center gap-4">
                        <div
                          className={`p-3 rounded-2xl ${
                            tx.type === 'TARIK' ? 'bg-orange-50 text-orange-600' : tx.type === 'TOPUP' ? 'bg-blue-50 text-blue-600' : 'bg-green-50 text-green-600'
                          }`}
                        >
                          {tx.type === 'TARIK' ? <ArrowDownLeft size={20} /> : tx.type === 'TOPUP' ? <PlusCircle size={20} /> : <ArrowUpRight size={20} />}
                        </div>
                        <div>
                          <p className="font-black text-slate-800 text-xs uppercase tracking-tight">{tx.customerName}</p>
                          <p className="text-[9px] text-slate-400 font-bold uppercase mt-0.5">{tx.type}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-black text-sm ${tx.type === 'TARIK' ? 'text-red-500' : 'text-green-600'}`}>
                          {tx.type === 'TARIK' ? '-' : '+'}
                          {formatCurrency(tx.amount)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <BottomNav />
            </>
          )}

          {currentPage === 'cashbook' && (
            <div className="min-h-screen bg-slate-50 pb-24">
              <SectionHeader title="Buku Kas" showBack={true} />
              <div className="px-6 space-y-4">
                <div className="bg-white p-7 rounded-[32px] shadow-sm border border-slate-100 flex justify-between items-center">
                  <div>
                    <p className="text-[10px] text-slate-400 font-black mb-1 uppercase tracking-widest">Posisi Kas Laci</p>
                    <h3 className="text-3xl font-black text-slate-800 tracking-tighter">{formatCurrency(balance.cash)}</h3>
                  </div>
                  <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl">
                    <Wallet size={28} />
                  </div>
                </div>
                <div className="space-y-3">
                  <p className="text-[10px] font-black text-slate-400 px-2 uppercase tracking-[0.2em]">Alur Mutasi Kas</p>
                  {transactions.map(tx => (
                    <div key={tx.id} className="bg-white p-5 rounded-[28px] flex items-center justify-between shadow-sm border border-slate-50">
                      <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-2xl ${tx.type === 'TARIK' ? 'bg-red-50 text-red-500' : 'bg-green-50 text-green-500'}`}>
                          {tx.type === 'TARIK' ? <ArrowDownLeft size={20} /> : <ArrowUpRight size={20} />}
                        </div>
                        <div>
                          <p className="text-xs font-black text-slate-800 uppercase tracking-tight leading-none mb-1">{tx.customerName}</p>
                          <p className="text-[9px] text-slate-400 font-bold uppercase">{tx.type}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-black text-sm ${tx.type === 'TARIK' ? 'text-red-500' : 'text-green-600'}`}>
                          {tx.type === 'TARIK' ? '-' : '+'} {formatCurrency(tx.amount)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <BottomNav />
            </div>
          )}

          {currentPage === 'report' && <ReportPage />}
          {currentPage === 'account' && <AccountPage />}
          {currentPage === 'settings' && <SettingsPage />}

          <TransactionModal />
          <TopupModal />
          <CloseDrawerModal />

          {showReceipt && (
            <div className="fixed inset-0 z-[110] bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-6">
              <div className="bg-white w-full max-sm rounded-[48px] p-10 space-y-8 text-center shadow-2xl relative">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-green-500 text-white rounded-full flex items-center justify-center border-[10px] border-white shadow-2xl shadow-green-200">
                  <CheckCircle2 size={44} />
                </div>
                <div className="pt-8">
                  <h3 className="text-3xl font-black uppercase tracking-tight text-slate-800 leading-none">Berhasil!</h3>
                </div>
                <div className="bg-slate-50 p-8 rounded-[40px] space-y-4 text-left border border-slate-100">
                  <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    <span>Nasabah</span>
                    <span className="text-slate-800">{showReceipt.customerName}</span>
                  </div>
                  <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    <span>Tipe</span>
                    <span className="text-slate-800">{showReceipt.type}</span>
                  </div>
                  <div className="border-t border-slate-200 pt-5 flex justify-between items-center">
                    <span className="text-xs font-black uppercase text-slate-400 tracking-widest">Total Bayar</span>
                    <span className="text-blue-600 font-black text-2xl tracking-tighter">{formatCurrency(showReceipt.amount + showReceipt.fee)}</span>
                  </div>
                </div>
                <button onClick={() => setShowReceipt(null)} className="w-full bg-blue-600 text-white py-6 rounded-[24px] font-black uppercase tracking-[0.2em] text-xs">
                  TUTUP
                </button>
              </div>
            </div>
          )}
        </>
      )}

      {/* Global Notifications */}
      <div className="fixed top-8 left-1/2 -translate-x-1/2 z-[200] space-y-3 w-full max-w-[340px] px-4 print:hidden">
        {notifications.map(n => (
          <div key={n.id} className="bg-slate-900 text-white px-6 py-5 rounded-[24px] shadow-2xl flex items-center gap-5 animate-in fade-in slide-in-from-top duration-500 border border-white/10 backdrop-blur-md">
            <div className="w-10 h-10 bg-blue-500/20 text-blue-400 rounded-2xl flex items-center justify-center flex-shrink-0">
              <ShieldCheck size={20} />
            </div>
            <span className="text-[11px] font-black uppercase tracking-widest leading-relaxed">{n.message}</span>
          </div>
        ))}
      </div>

      <style
        dangerouslySetInnerHTML={{
          __html: `
        @media print {
          body { background-color: white !important; }
          .app-container { background-color: white !important; padding-bottom: 0 !important; }
          .print\\:hidden { display: none !important; }
          .print\\:block { display: block !important; }
          .print\\:text-center { text-align: center !important; }
          .print\\:text-slate-900 { color: #0f172a !important; }
          .print\\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)) !important; }
          .print\\:border-slate-300 { border-color: #cbd5e1 !important; }
          .print\\:shadow-none { shadow: none !important; }
        }
      `
        }}
      />
    </div>
  )
}
