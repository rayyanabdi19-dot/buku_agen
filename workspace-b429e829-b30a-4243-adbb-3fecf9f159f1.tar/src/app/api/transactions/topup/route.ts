import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { userId, dailyStatusId, type, amount, source } = await request.json()

    if (!userId || !dailyStatusId || !type || !amount || !source) {
      return NextResponse.json(
        { success: false, message: 'Data tidak lengkap!' },
        { status: 400 }
      )
    }

    // Create TOPUP transaction
    const transaction = await db.transaction.create({
      data: {
        userId,
        dailyStatusId,
        type: 'TOPUP',
        amount: parseFloat(amount),
        fee: 0,
        customerName: `MODAL: ${source.toUpperCase()} - ${type === 'CASH' ? 'KAS LACI' : 'REKENING'}`,
        target: type === 'CASH' ? 'KAS LACI' : 'REKENING',
        status: 'SUCCESS'
      }
    })

    // Calculate new balances
    const allTransactions = await db.transaction.findMany({
      where: { dailyStatusId }
    })

    const dailyStatus = await db.dailyStatus.findUnique({
      where: { id: dailyStatusId }
    })

    if (!dailyStatus) {
      return NextResponse.json(
        { success: false, message: 'Status harian tidak ditemukan!' },
        { status: 404 }
      )
    }

    let cashBalance = dailyStatus.cashStart
    let bankBalance = dailyStatus.bankStart

    allTransactions.forEach(tx => {
      if (tx.type === 'TOPUP') {
        if (tx.customerName?.toUpperCase().includes('KAS LACI')) {
          cashBalance += tx.amount
        } else if (tx.customerName?.toUpperCase().includes('REKENING')) {
          bankBalance += tx.amount
        }
      } else if (tx.type === 'TARIK') {
        cashBalance -= tx.amount
        bankBalance += tx.amount + tx.fee
      } else {
        // SETOR or TRANSFER
        cashBalance += tx.amount + tx.fee
        bankBalance -= tx.amount
      }
    })

    return NextResponse.json({
      success: true,
      transaction: {
        id: transaction.id,
        type: transaction.type,
        amount: transaction.amount,
        fee: transaction.fee,
        timestamp: transaction.createdAt.toISOString(),
        customerName: transaction.customerName,
        target: transaction.target,
        status: transaction.status
      },
      cashBalance,
      bankBalance
    })
  } catch (error) {
    console.error('Topup error:', error)
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat top up' },
      { status: 500 }
    )
  }
}
