import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { dailyStatusId, cashEnd, bankEnd } = await request.json()

    if (!dailyStatusId || cashEnd === undefined || bankEnd === undefined) {
      return NextResponse.json(
        { success: false, message: 'Data tidak lengkap!' },
        { status: 400 }
      )
    }

    const dailyStatus = await db.dailyStatus.findUnique({
      where: { id: dailyStatusId }
    })

    if (!dailyStatus) {
      return NextResponse.json(
        { success: false, message: 'Status harian tidak ditemukan!' },
        { status: 404 }
      )
    }

    if (dailyStatus.status === 'CLOSED') {
      return NextResponse.json(
        { success: false, message: 'Shift sudah ditutup!' },
        { status: 400 }
      )
    }

    const updatedDailyStatus = await db.dailyStatus.update({
      where: { id: dailyStatusId },
      data: {
        timeClose: new Date(),
        status: 'CLOSED'
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Shift berhasil ditutup',
      dailyStatus: {
        id: updatedDailyStatus.id,
        userId: updatedDailyStatus.userId,
        date: updatedDailyStatus.date,
        cashStart: updatedDailyStatus.cashStart,
        bankStart: updatedDailyStatus.bankStart,
        cashEnd,
        bankEnd,
        timeOpen: updatedDailyStatus.timeOpen.toISOString(),
        timeClose: updatedDailyStatus.timeClose?.toISOString(),
        status: updatedDailyStatus.status
      }
    })
  } catch (error) {
    console.error('Close drawer error:', error)
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat menutup shift' },
      { status: 500 }
    )
  }
}
